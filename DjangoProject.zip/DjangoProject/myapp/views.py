#importar todo lo necesario que usaremos mas adelante
from django.http import HttpResponse, JsonResponse
from .models import Project, Task
from django.shortcuts import get_object_or_404, render

from .forms import crearcomentario

# Create your views here.

#secciones 
#creamos una variable titulo la que almacenara una frase que llamaremos al index
def index(request):
    title = "Bienvenido a WIKIColabora: Tu Guía Definitiva de Tecnología"
    return render(request, 'index.html', {
        "title" : title
    })

def diferencias(request):
    username = "PEPE"
    return render(request, 'diferencias.html',{
        "username" : username
    })

def servicios(request):
    return render(request, 'servicios.html')

#creamos la funcion para comentar
def comentarios(request):
    print(request.GET['tittle'])
    print(request.GET['descripcion'])
    return render(request, 'comentarios.html',{
        "form" : crearcomentario()
    
    })

#concatenar parametros que vayan cambiando
def hello(request, id):
    print(type(id))
    return HttpResponse("<h1>Hello %s</h1>" % id)

def projects(request):
    projects = list(Project.objects.values())
    return JsonResponse(projects, safe=False)

def tasks(request, tittle):
    task = get_object_or_404(Task, tittle=tittle)
    return HttpResponse('task: %s' % task.tittle)


