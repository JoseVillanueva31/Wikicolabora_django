from django import forms

#creamos la funcion para ingresar un comentario 
class crearcomentario(forms.Form):
    titulo = forms.CharField(label="titulo de comentario", max_length=200)
    descripcion= forms.CharField(label="descripcion del comentario" ,widget=forms.Textarea)
