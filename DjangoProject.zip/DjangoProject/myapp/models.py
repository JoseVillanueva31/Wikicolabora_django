from django.db import models

# Create your models here.
class Project(models.Model):
    name = models.CharField(max_length=200)
    
    def __str__(self):
        return self.name

#crear tabla nueva Task    

class Task(models.Model):
    title =models.CharField(max_length=200)
    description = models.TextField()

    #aca decimos que tendra una relacion con la tabla de project
    #ademas añadimos que cuando elimine project se eliminen 
    #todas la tablas con las que se relaciona

    projects = models.ForeignKey(Project, on_delete=models.CASCADE)
    done = models.BooleanField(default=False)

    #codigo para mostrar el titulo  o nombre de la tarea

    def __str__(self):
        return self.tittle + ' - ' + self.projects.name