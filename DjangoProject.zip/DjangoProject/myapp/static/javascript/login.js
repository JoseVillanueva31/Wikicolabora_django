// Código para el formulario de inicio de sesión
const formInicioSesion = document.getElementById("login-in");
const correoLogin = document.getElementById("correo-login");
const contrasenaLogin = document.getElementById("password-login");
const parrafoLogin = document.getElementById("alerta-login");

// Evento de envío del formulario de inicio de sesión
formInicioSesion.addEventListener("submit", function(event) {
    event.preventDefault();

    // Obtener los datos de usuario almacenados en localStorage
    const usuarioAlmacenado = JSON.parse(localStorage.getItem("usuario"));

    // Verificar si los datos ingresados coinciden con los almacenados
    if (usuarioAlmacenado) {
        if (usuarioAlmacenado.correo === correoLogin.value && usuarioAlmacenado.contrasena === contrasenaLogin.value) {
            // Si coinciden, redirigir a la página de inicio (index.html)
            window.location.href = "index.html";
        } else {
            // Si no coinciden, mostrar un mensaje de error
            parrafoLogin.innerHTML = "!Correo o contraseña incorrectos¡";
        }
    } else {
        // Si no hay datos almacenados, mostrar un mensaje de error
        parrafoLogin.innerHTML = "No hay usuarios registrados. Por favor, regístrese primero.";
    }
});
