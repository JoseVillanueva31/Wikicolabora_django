from django.urls import path
from . import views 

#asegurarse que la url este biene escrita 
urlpatterns = [
    #urls principales
    path('', views.index),
    path('diferencias/', views.diferencias),
    path('servicios/', views.servicios),
    path('login/', views.login),
    path('register/', views.register),
    path('comentarios/', views.comentarios),

    #urls de prueba
    path('hello/<int:id>', views.hello),
    path('projects/', views.projects),
    path('tasks/<int:tittle>', views.tasks)
]
    