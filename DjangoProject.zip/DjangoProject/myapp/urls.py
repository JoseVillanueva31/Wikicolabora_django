from django.urls import path
from . import views 

#asegurarse que la url este biene escrita 
urlpatterns = [
    path('', views.index),
    path('diferencias/', views.diferencias),
    path('servicios/', views.servicios),
    path('comentarios/', views.comentarios),
    path('hello/<int:id>', views.hello),
    path('projects/', views.projects),
    path('tasks/<int:tittle>', views.tasks)
]
    